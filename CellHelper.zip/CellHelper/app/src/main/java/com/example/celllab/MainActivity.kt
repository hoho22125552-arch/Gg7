package com.example.celllab

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

private class Step(val title: String, val cell: String, val actions: List<String>)

class MainActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }

    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var descField: EditText
    private lateinit var goBtn: Button
    private lateinit var copyBtn: Button
    private lateinit var status: TextView
    private lateinit var progressText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var result: LinearLayout

    private var steps: List<Step> = emptyList()
    private var done = BooleanArray(0)
    private var guideTitle = ""
    private var idea = ""
    private var tips: List<String> = emptyList()
    private val cardViews = ArrayList<View>()
    private val titleViews = ArrayList<TextView>()
    private val badgeViews = ArrayList<TextView>()
    private var pulseAnim: ObjectAnimator? = null

    private val GREEN = Color.rgb(46, 204, 113)
    private val CARD = Color.rgb(24, 30, 40)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun rounded(fill: Int, r: Int, stroke: Int = 0, sw: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(r).toFloat()
            if (sw > 0) setStroke(dp(sw), stroke)
        }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(top) }

    private fun accent(cell: String): Int {
        val c = cell.lowercase()
        return when {
            "phago" in c -> Color.rgb(255, 167, 38)
            "flagel" in c -> Color.rgb(66, 165, 245)
            "photo" in c -> Color.rgb(102, 187, 106)
            "devor" in c -> Color.rgb(239, 83, 80)
            "lipo" in c -> Color.rgb(255, 238, 88)
            "kerat" in c -> Color.rgb(161, 136, 127)
            "buoy" in c -> Color.rgb(128, 222, 234)
            "glue" in c -> Color.rgb(186, 104, 200)
            "viro" in c -> Color.rgb(212, 225, 87)
            "nitro" in c -> Color.rgb(255, 112, 67)
            "stem" in c -> Color.rgb(189, 189, 189)
            "sense" in c -> Color.rgb(77, 208, 225)
            "myo" in c -> Color.rgb(240, 98, 146)
            "neuro" in c -> Color.rgb(149, 117, 205)
            "secro" in c -> Color.rgb(174, 213, 129)
            "stereo" in c -> Color.rgb(144, 164, 174)
            else -> GREEN
        }
    }

    private fun field(hintText: String, lines: Int = 1): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.argb(110, 255, 255, 255))
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(27, 33, 44), 12, Color.argb(60, 255, 255, 255), 1)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        if (lines > 1) {
            minLines = lines
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.rgb(15, 19, 26)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(15, 19, 26)) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(40))
        }
        scroll.addView(col)

        col.addView(TextView(this).apply {
            text = "🧬 Cell Lab помощник"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "Опиши существо — получишь пошаговую инструкцию, что нажимать и какие значения выставлять в редакторе генома."
            textSize = 14f
            setTextColor(Color.argb(170, 255, 255, 255))
        }, lp(6))

        keyField = field("Ключ OpenRouter (sk-or-...)").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        modelField = field("Модель").apply { setText(prefs.getString("model", "openrouter/auto")) }
        descField = field("Например: быстрый хищник, который ест мелких клеток и умеет плавать", 4)
        col.addView(keyField, lp(18))
        col.addView(modelField, lp(10))
        col.addView(descField, lp(10))

        goBtn = Button(this).apply {
            text = "Составить инструкцию"
            isAllCaps = false
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(10, 25, 15))
            background = rounded(GREEN, 14)
            setOnClickListener { generate() }
        }
        col.addView(goBtn, lp(14))

        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.argb(210, 255, 255, 255))
            visibility = View.GONE
        }
        col.addView(status, lp(14))

        progressText = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.argb(180, 255, 255, 255))
            visibility = View.GONE
        }
        col.addView(progressText, lp(18))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(GREEN)
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(50, 255, 255, 255))
            visibility = View.GONE
        }
        col.addView(progress, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(6) })

        result = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(result, lp(8))

        copyBtn = Button(this).apply {
            text = "Скопировать инструкцию"
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(Color.rgb(38, 46, 60), 14, Color.argb(70, 255, 255, 255), 1)
            visibility = View.GONE
            setOnClickListener { copyGuide() }
        }
        col.addView(copyBtn, lp(16))

        setContentView(scroll)

        val last = prefs.getString("last", null)
        if (last != null) {
            val obj = parseObj(last)
            if (obj != null) applyGuide(obj, prefs.getString("done", "") ?: "")
        }
    }

    // ---------- запрос ----------
    private fun generate() {
        val key = keyField.text.toString().trim()
        val desc = descField.text.toString().trim()
        if (key.isEmpty()) { showStatus("Вставь ключ OpenRouter"); return }
        if (desc.isEmpty()) { showStatus("Опиши, какое существо нужно"); return }
        val model = modelField.text.toString().trim().ifEmpty { "openrouter/auto" }
        prefs.edit().putString("key", key).putString("model", model).apply()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(descField.windowToken, 0)
        goBtn.isEnabled = false
        startLoading()
        io.execute {
            val raw = try { ask(key, model, desc) } catch (e: Exception) { "ERR:" + e.message }
            main.post { onResult(raw) }
        }
    }

    private fun startLoading() {
        status.text = "Составляю инструкцию…"
        status.visibility = View.VISIBLE
        pulseAnim?.cancel()
        pulseAnim = ObjectAnimator.ofFloat(status, "alpha", 1f, 0.3f).apply {
            duration = 700
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }
    }

    private fun stopLoading() {
        pulseAnim?.cancel()
        status.alpha = 1f
    }

    private fun showStatus(msg: String) {
        stopLoading()
        status.text = msg
        status.visibility = View.VISIBLE
    }

    private fun parseObj(raw: String): JSONObject? {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try { JSONObject(raw.substring(s, e + 1)) } catch (ex: Exception) { null }
    }

    private fun onResult(raw: String) {
        stopLoading()
        goBtn.isEnabled = true
        if (raw.startsWith("ERR:")) {
            showStatus("⚠ " + raw.removePrefix("ERR:").take(200))
            return
        }
        val obj = parseObj(raw)
        val n = obj?.optJSONArray("steps")?.length() ?: 0
        if (obj == null || n == 0) {
            showStatus("Не получилось разобрать ответ. Попробуй ещё раз или выбери другую модель.")
            return
        }
        prefs.edit().putString("last", obj.toString()).putString("done", "").apply()
        status.visibility = View.GONE
        applyGuide(obj, "")
    }

    private fun ask(key: String, model: String, desc: String): String {
        val sys = "Ты эксперт по игре Cell Lab: Evolution Sandbox — песочнице, где игрок собирает организм в редакторе генома. " +
            "Пользователь описывает существо, которое хочет получить. Выдай пошаговую инструкцию: что именно нажимать и какие значения выставлять в редакторе генома. " +
            "Что известно об игре: геном состоит из режимов (modes). У каждого режима выбирается тип клетки, например Phagocyte, Flagellocyte, Photocyte, Devorocyte, Lipocyte, Keratinocyte, Buoyocyte, Glueocyte, Virocyte, Stem Cell, Senseocyte, Myocyte, Neurocyte, Secrocyte, Stereocyte. " +
            "У режима есть настройки деления: соотношение масс, угол деления, интервал деления, режимы дочерних клеток Child A и Child B, адгезия (остаются ли дочерние клетки связанными), цвет. Один из режимов — начальный. " +
            "Опирайся только на то, что знаешь точно. Если не уверен в названии кнопки, настройки или в числе — опиши действие общими словами и поставь (?). Числа давай как стартовые значения и подсказывай, как их подстроить после теста. " +
            "Структура шагов: сначала подготовка (новый геном), затем по одному шагу на каждый режим (в заголовке номер режима и роль, в cell — английское название типа клетки, в actions — что нажать и что выставить, включая на какие режимы указывают Child A и Child B), в конце проверка в игре. Не больше 12 шагов, действия короткие, в повелительном наклонении. " +
            "Верни ТОЛЬКО JSON без пояснений: {\"name\":\"название существа\",\"idea\":\"как оно работает, 1–2 предложения\"," +
            "\"steps\":[{\"title\":\"Режим 1: роль\",\"cell\":\"Phagocyte\",\"actions\":[\"...\",\"...\"]}],\"tips\":[\"...\"]}. Отвечай по-русски."
        val body = JSONObject()
            .put("model", model).put("max_tokens", 3000).put("temperature", 0.3)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", sys))
                .put(JSONObject().put("role", "user").put("content", desc)))
        val c = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $key")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode >= 400) return "ERR:API ${c.responseCode}: $resp".take(300)
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    // ---------- отображение ----------
    private fun applyGuide(obj: JSONObject, doneStr: String) {
        guideTitle = obj.optString("name", "Существо")
        idea = obj.optString("idea", "")
        val arr = obj.optJSONArray("steps") ?: JSONArray()
        val list = ArrayList<Step>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val acts = ArrayList<String>()
            val aa = o.optJSONArray("actions")
            if (aa != null) for (k in 0 until aa.length()) acts.add(aa.optString(k))
            list.add(Step(o.optString("title", "Шаг ${i + 1}"), o.optString("cell", ""), acts))
        }
        steps = list
        val tl = ArrayList<String>()
        val ta = obj.optJSONArray("tips")
        if (ta != null) for (k in 0 until ta.length()) tl.add(ta.optString(k))
        tips = tl
        done = BooleanArray(list.size)
        for (p in doneStr.split(",")) {
            val idx = p.trim().toIntOrNull()
            if (idx != null && idx in done.indices) done[idx] = true
        }
        render()
    }

    private fun render() {
        result.removeAllViews()
        cardViews.clear(); titleViews.clear(); badgeViews.clear()
        if (steps.isEmpty()) {
            progress.visibility = View.GONE
            progressText.visibility = View.GONE
            copyBtn.visibility = View.GONE
            return
        }
        result.addView(TextView(this).apply {
            text = guideTitle
            textSize = 22f
            setTextColor(GREEN)
            typeface = Typeface.DEFAULT_BOLD
        })
        if (idea.isNotBlank()) {
            result.addView(TextView(this).apply {
                text = idea
                textSize = 14f
                setTextColor(Color.argb(210, 255, 255, 255))
            }, lp(4))
        }
        steps.forEachIndexed { i, s -> addCard(i, s) }
        if (tips.isNotEmpty()) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Color.rgb(30, 36, 28), 16, withAlpha(GREEN, 90), 1)
                setPadding(dp(14), dp(12), dp(14), dp(14))
            }
            box.addView(TextView(this).apply {
                text = "💡 Советы"
                textSize = 15f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            })
            for (t in tips) {
                box.addView(TextView(this).apply {
                    text = "•  $t"
                    textSize = 14f
                    setTextColor(Color.argb(225, 255, 255, 255))
                }, lp(6))
            }
            result.addView(box, lp(14))
        }
        copyBtn.visibility = View.VISIBLE
        updateProgress(false)
    }

    private fun addCard(i: Int, s: Step) {
        val ac = accent(s.cell)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, 16, withAlpha(ac, 150), 1)
            setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val badge = TextView(this).apply {
            text = "${i + 1}"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(15, 19, 26))
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ac) }
        }
        head.addView(badge, LinearLayout.LayoutParams(dp(32), dp(32)))
        val titleV = TextView(this).apply {
            text = s.title
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), 0, 0, 0)
        }
        head.addView(titleV, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(head)
        if (s.cell.isNotBlank()) {
            card.addView(TextView(this).apply {
                text = s.cell
                textSize = 12f
                setTextColor(ac)
                background = rounded(withAlpha(ac, 40), 8)
                setPadding(dp(10), dp(3), dp(10), dp(3))
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) })
        }
        for (a in s.actions) {
            card.addView(TextView(this).apply {
                text = "•  $a"
                textSize = 14f
                setTextColor(Color.argb(230, 255, 255, 255))
            }, lp(6))
        }
        cardViews.add(card); titleViews.add(titleV); badgeViews.add(badge)
        applyDoneVisual(i)
        card.setOnClickListener { toggle(i) }

        val target = if (done[i]) 0.5f else 1f
        card.alpha = 0f
        card.translationY = dp(30).toFloat()
        result.addView(card, lp(10))
        card.animate().alpha(target).translationY(0f).setStartDelay(i * 70L).setDuration(350)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun applyDoneVisual(i: Int) {
        val t = titleViews[i]
        val bd = badgeViews[i]
        if (done[i]) {
            t.paintFlags = t.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
            bd.text = "✓"
        } else {
            t.paintFlags = t.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
            bd.text = "${i + 1}"
        }
    }

    private fun toggle(i: Int) {
        done[i] = !done[i]
        applyDoneVisual(i)
        val card = cardViews[i]
        card.animate().cancel()
        card.animate().alpha(if (done[i]) 0.5f else 1f).scaleX(0.97f).scaleY(0.97f).setStartDelay(0).setDuration(90)
            .withEndAction { card.animate().scaleX(1f).scaleY(1f).setDuration(140).start() }.start()
        prefs.edit().putString("done", done.indices.filter { done[it] }.joinToString(",")).apply()
        updateProgress(true)
    }

    private fun updateProgress(animate: Boolean) {
        val count = done.count { it }
        progress.visibility = View.VISIBLE
        progressText.visibility = View.VISIBLE
        progress.max = steps.size
        progress.setProgress(count, animate)
        progressText.text = "Выполнено $count из ${steps.size}"
        if (count == steps.size && steps.isNotEmpty()) {
            showStatus("🎉 Всё готово — существо собрано!")
        } else if (status.text.startsWith("🎉")) {
            status.visibility = View.GONE
        }
    }

    private fun copyGuide() {
        val sb = StringBuilder()
        sb.append(guideTitle).append("\n")
        if (idea.isNotBlank()) sb.append(idea).append("\n")
        steps.forEachIndexed { i, s ->
            sb.append("\n${i + 1}. ${s.title}")
            if (s.cell.isNotBlank()) sb.append(" (${s.cell})")
            sb.append("\n")
            for (a in s.actions) sb.append("   - ").append(a).append("\n")
        }
        if (tips.isNotEmpty()) {
            sb.append("\nСоветы:\n")
            for (t in tips) sb.append("- ").append(t).append("\n")
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("guide", sb.toString()))
        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
    }
}
